package softwarecomandosremotos;

public class listaips {
	
    public static final String IP_SERVIDOR_HOMOLOGACAO = "";

}
